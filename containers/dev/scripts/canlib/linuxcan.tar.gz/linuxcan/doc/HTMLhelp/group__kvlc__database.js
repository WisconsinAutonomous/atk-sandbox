var group__kvlc__database =
[
    [ "kvlcAddDatabase", "group__kvlc__database.html#gabf63c240a42cf4474f0e3fe9010e5f0b", null ],
    [ "kvlcAddDatabaseFile", "group__kvlc__database.html#ga1e1cd919e1c9b3ec0b7c45f7c8c6006b", null ]
];