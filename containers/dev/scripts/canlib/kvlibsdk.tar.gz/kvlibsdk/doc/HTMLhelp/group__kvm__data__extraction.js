var group__kvm__data__extraction =
[
    [ "kvmLogFileDeleteAll", "group__kvm__data__extraction.html#ga433fb7df698c9ad20100ea3a2ce79e85", null ],
    [ "kvmLogFileDismount", "group__kvm__data__extraction.html#ga56823defe7759f19b02aa20c2c602bc9", null ],
    [ "kvmLogFileGetCount", "group__kvm__data__extraction.html#ga9d8d0f08e18b85dd60fc4a5931a3717c", null ],
    [ "kvmLogFileGetCreatorSerial", "group__kvm__data__extraction.html#gab97303352868e3caa8d4dadae072a30b", null ],
    [ "kvmLogFileGetEndTime", "group__kvm__data__extraction.html#ga7f2f9c141e3a2c8e2feabfd134503607", null ],
    [ "kvmLogFileGetStartTime", "group__kvm__data__extraction.html#ga68a629a79c29a925274210a5acb3940c", null ],
    [ "kvmLogFileGetType", "group__kvm__data__extraction.html#ga92a778d90d79e5f4df83f20e65557180", null ],
    [ "kvmLogFileMount", "group__kvm__data__extraction.html#ga8907a1d15397ebb55856c8eb1d6b9134", null ],
    [ "kvmLogFileMountEx", "group__kvm__data__extraction.html#ga0554882347b158440d42ae0331d5ba1d", null ],
    [ "kvmLogFileReadEvent", "group__kvm__data__extraction.html#gafc50b92c12fda8d2fc7d40679d9d5b3c", null ]
];